# Deliverable Information
   > Please include your answers below in a good format so it is easy for me to see. For answers to questions please use these Blockquotes. Make sure you also check the kickoff document for more details.

## 1: Basic Information (needed before you start with your Sprint -- Sprint Planning)

Topic you chose: Topic 5 - Gym Scheduling

Sprint Number: 2

Scrum Master: Luis Ramirez

Git Master: Vignesh Subramanian

### Sprint Planning (For Sprint 1-4)
Document your Sprint Planning here. Also check the kickoff document for more details on what needs to be done. This is just the documentation. 

**Sprint Goal:** 

During this sprint, our goal is to continue our progress in refactoring the memoranda software in
order to present a more accurate representation of our Dojo software. We also plan on continuing our
efforts in following our Quality Policies throughout this sprint to stay consistent in our project 
as a team.

**How many User Stories did you add to the Product Backlog:**  12

**How many User Stories did you add to this Sprint:** 9

> Answer the questions below about your Sprint Planning?

**Why did you add exactly these US?**

> The User Stories that we added implement functionality based on who the user is (Owner, Trainer, Student). Each user will be able to login to the Dojo program and be able to execute different 
operations based on requirements. These US are important so that the Owner is able to manage the gym through their login while trainers and students are kept from performing tasks that only the 
Owner should be capable of performing.

**Why do you think you will get them done? (details)**

> Some of the US that we added deal with the login feature which is a work in progress from Sprint 1 while other US require more refactoring and implementation of UI operations.

**Do you have a rough idea what you need to do? (if the answer is no then please let me know on Slack)**

> Yes, we have a pretty good idea of what we would like to accomplish over the course of this sprint and what
it will take to accomplish it all. We will contact the professor or post on Slack if additional help is needed.

## 2: During the Sprint
> Fill out the Meeting minutes during your Sprint and keep track of things. Update your Quality policies when needed, as explained in the lectures and in the Quality Policy documents on Canvas. 
I would also advise you to already fill out the Contributions section (End of sprint) as you go, to create less work at the end.

### Meeting minutes of your Daily Scrums (3 per week, should not take longer than 10 minutes):
> Add as many rows as needed and fill out the table. (Burndown starts with Sprint 2 and Travis CI starts with Sprint 3, not needed before that)

Sprint 1
|  Date  | Attendees   |Minutes   | Burndown Info | TravisCI info | Additional Info                                                                               |
|--------|-------------|----------|---------------|---------------|-----------------------------------------------------------------------------------------------|
|04/16/20|             |    11    |               |               |                                                                                               |
|        |Chase        |          | 1 point       | n/a           | Modified "About" section and created login UI. Continually working on tasks and testing       |
|        |Edward       |          | 3 points      | n/a           | Working on Unit Testing User Story and US59                                                   |
|        |Vignesh      |          | n/a           | n/a           | Assigned user story in progress                                                               |
|        |Luis         |          | 5 points      | n/a           | Completed US85, working on US49                                                               |
|        |Donald       |          | 5 points      | n/a           | Completed Login backend and working on additional login/registration functionality            |
|--------|-------------|----------|---------------|---------------|-----------------------------------------------------------------------------------------------|
|04/17/20|             |    15    |               |               |                                                                                               |
|        |Chase        |          | 14 points     | n/a           | US36-Task42-LoginUI has been pushed to repo and ready for testing. Free to help where needed. |
|        |Edward       |          | 3 points      | n/a           | Working with Donald on registering for classes and updating GUI.                              | 
|        |Vignesh      |          | n/a           | n/a           | Assigned user story in progress                                                               |
|        |Luis         |          | 5 points      | n/a           | Helping in keeping Taiga board on track and helping review completed user stories.            |
|        |Donald       |          | 5 points      | n/a           | Completed US81-Task83 and beginning work on US81-Task82.                                      |
|--------|-------------|----------|---------------|---------------|-----------------------------------------------------------------------------------------------|
|04/18/20|             |    15    |               |               |                                                                                               |
|        |Chase        |          | 14 points     | n/a           | Updated Taiga and working on tests for completed user stories. Free to help where needed.     |
|        |Edward       |          | 9 points      | n/a           | Working on integrating scheduling class logic and UI.                                         | 
|        |Vignesh      |          | 1 point       | n/a           | n/a                                                                                           |
|        |Luis         |          | 5 points      | n/a           | Helping with reviewing pull requests/testing completed user stories. Free to help where needed|
|        |Donald       |          | 5 points      | n/a           | US81-Task82 is in progress.                                                                   |

### Meeting Summary:

> Add rows as needed and add the number how many meetings they attended:

   Chase Brown :          3
   Donald Anderson:       3
   Edward Miller:         3
   Vignesh Subramanian:   2
   Luis Ramirez-Zamacona: 3
   
   Note: There were difficulties in finding appropriate dates and times to meet due to other course exams, thus for our last 2 stand up meetings we posted updates to our standup channel. We also have a trail of keeping eachother posted on our team channel throughout this sprint.

## 3: After the Sprint

### Sprint Review

**Screen Cast link**: https://www.youtube.com/watch?v=jaFoBDcNG98&feature=youtu.be

> Answer the following questions as a team. 

**What do you think is the value you created this Sprint?**

> The most valuable feature that was incorporated to our program for this sprint is the login feature. We are now able to login and register users and save their credentials to the software. Other values to the program include modifying the software to represent the Dojo software more than what we did in sprint 1 where we mainly focused on fixing bugs left from the memoranda software.

**Do you think you worked enough and that you did what was expected of you?**

> With testing being the new practice incorporated in this sprint, we believe that we worked hard and accomplished what was expected of us. Throughout this sprint we communicated on slack once a task was ready for testing and if there were any issues or additional features that needed to be added then we'd communicate that to one another as well.

**Would you say you met the customers’ expectations? Why, why not?**

> We believe we are on track with the customer's expectations because even though it may seem like there aren't a lot of features that were added to the software we were able to handle what we thought we could and thus we did not leave the customer expecting more than what was initially agreed upon at the start of the sprint.

### Sprint Retrospective

> Include your Sprint retrospective here and answer the following questions in an evidence based manner as a team (I do not want each of your individuals opinion here but the team perspective). By evidence-based manner it means I want a Yes or No on each of these questions, and for you to provide evidence for your answer. That is, don’t just say "Yes we did work at a consistent rate because we tried hard"; say "we worked at a consistent rate because here are the following tasks we completed per team member and the rate of commits in our Git logs."

**Did you meet your sprint goal?**

> We met our goal of modifying the memoranda project to have a more accurate representation of our Dojo software. 

**Did you complete all stories on your Spring Backlog?**

> We did not complete all of the stories in our sprint backlog.

**If not, what went wrong?**

> The some of the US in our backlog are additional functionalities to our login process which is a feature that we focused on and were able to complete this sprint.
  Other US include the class scheduling features which is a task that our taiga taskboard will show is currently in process.

**Did you work at a consistent rate of speed, or velocity? (Meaning did you work during the whole Sprint or did you start working when the deadline approached.)**

> Our burndown chart will show that our US were completed more towards the end of the sprint and not near the expected slope, but we consistently worked and updated one another throughout this sprint and our slack team channel will show this.

**Did you deliver business value?**

> We delivered business value by providing the owner with the ability to log into the Dojo software as well as register users with the appropriate information. The owner is now also able to see that the panel images represent a Dojo look and feel as well.

**Are there things the team thinks it can do better in the next Sprint?**

> We all agree that we need to have a better planning and transitioning process for this next sprint.

**How do you feel at this point? Get a pulse on the optimism of the team.**

> There is definitely a lot to take in and a lot of processes to remember, but as a team we have done a pretty good job at accomplishing our tasks and being able to help one another stay on track.

### Contributions:

> In this section I want you to point me to your main contributions (each of you individually). Some of the topcs are not needed for the first deliverables (you should know which things you should have done in this Sprint, if you don't then you have probably missed something):

#### Luis Ramirez-Zamacona:
  **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US85-UpdateNotesPanel

  **GitHub links to your Unit Tests (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/blob/Development/src/tests/Whitebox.java

  **GitHub links to your Code Reviews (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/pull/4
    - https://github.com/amehlhase316/Mohnkuchen/pull/7
    - https://github.com/amehlhase316/Mohnkuchen/pull/12
 
  **What was your main contribution to the Quality Policy documentation?:

    - Updated the Github workflow to be more representative of our Dojo project, helped with the Whitebox policy and provided a checklist for our code reviews.

#### Chase Brown:
  **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US79-AboutDojo
    - https://github.com/amehlhase316/Mohnkuchen/tree/US36-Task42-LoginUI
    - https://github.com/amehlhase316/Mohnkuchen/tree/US90

  **GitHub links to your Unit Tests (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/blob/master/src/tests/Blackbox.java

  **GitHub links to your Code Reviews (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/pull/8#issuecomment-616266610
    - https://github.com/amehlhase316/Mohnkuchen/pull/9#issuecomment-616266059
    - https://github.com/amehlhase316/Mohnkuchen/pull/16#issuecomment-616265389

  **What was your main contribution to the Quality Policy documentation?:

    - Reviewed the additions added by Luis to the whitebox section and modifications made to the rest of the Quality Policy.

#### Don Anderson djande23
  **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US36-Task83-SetClassLimit
    - https://github.com/amehlhase316/Mohnkuchen/tree/US81-Task82-SaveClassRegistration

  **GitHub links to your Unit Tests (up to 3 links):

    - 

  **GitHub links to your Code Reviews (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/pull/17

  **What was your main contribution to the Quality Policy documentation?:
    
    - Discussed and reviewed with team.

#### Vignesh Subramanian
   **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/us12-task31

   **GitHub links to your Unit Tests (up to 3 links):

    - 

   **GitHub links to your Code Reviews (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/pull/19
    - https://github.com/amehlhase316/Mohnkuchen/pull/14

  **What was your main contribution to the Quality Policy documentation?:

    - Reviewed and verified Quality Policy document.

#### Edward Miller
  **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/Task60-AddScheduleClassButton
    - https://github.com/amehlhase316/Mohnkuchen/tree/US36-Task44-TrackRegistrations
    - https://github.com/amehlhase316/Mohnkuchen/tree/US59-Task61-AddJoinClass
    - https://github.com/amehlhase316/Mohnkuchen/tree/US59-Task89-ChangeIcons

  **GitHub links to your Unit Tests (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/blob/master/src/tests/Blackbox.java

  **GitHub links to your Code Reviews (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/pull/17
    - https://github.com/amehlhase316/Mohnkuchen/pull/13
    - https://github.com/amehlhase316/Mohnkuchen/pull/19#issuecomment-616274735
    - https://github.com/amehlhase316/Mohnkuchen/pull/12

  **What was your main contribution to the Quality Policy documentation?:
    
    - Blackbox testing policy
  
## 4: Checklist for you to see if you are done
- [X] Filled out the complete form from above, all fields are filled and written in full sentences
- [X] Read the kickoff again to make sure you have all the details
- [X] User Stories that were not completed, were left in the Sprint and a copy created
- [X] Your Quality Policies are accurate and up to date
- [X] **Individual** Survey was submitted **individually** (create checkboxes below -- see Canvas to get link)
  - [X] Bradley Chase Brown
  - [X] Edward Miller
  - [X] Donald Anderson
  - [X] Luis Ramirez-Zamacona
  - [X] Vignesh Subramanian
- [X] The original of this file was copied for the next Sprint (needed for all but last Sprint where you do not need to copy it anymore)
  - [X] Basic information (part 1) for next Sprint was included (meaning Spring Planning is complete)
  - [X] All User Stories have acceptance tests
  - [X] User Stories in your new Sprint Backlog have initial tasks which are in New
  - [X] You know how to proceed

# Deliverable Information
   > Please include your answers below in a good format so it is easy for me to see. For answers to questions please use these Blockquotes. Make sure you also check the kickoff document for more details.

## 1: Basic Information (needed before you start with your Sprint -- Sprint Planning)

Topic you chose: Topic 5 - Gym Scheduling

Sprint Number: 2

Scrum Master: Donald Anderson

Git Master: Luis Ramirez-Zamacona

### Sprint Planning (For Sprint 1-4)
Document your Sprint Planning here. Also check the kickoff document for more details on what needs to be done. This is just the documentation. 

**Sprint Goal:** 

During this sprint, our goal is to put some final touches on the Dojo software and implement many of the key features required for the program.
It will be a very busy and active sprint that requires a lot of communication.

**How many User Stories did you add to the Product Backlog:**  14

**How many User Stories did you add to this Sprint:** 14

> Answer the questions below about your Sprint Planning?

**Why did you add exactly these US?**

> These were all of the remaining US's for our project. We thought that it would be good to try and get as much done as we could over this last sprint.

**Why do you think you will get them done? (details)**

> We have the foundation of the program set, so many of these changes will be much easier to implement than they would have been in previous sprints.

**Do you have a rough idea what you need to do? (if the answer is no then please let me know on Slack)**

> There is a lot to do but we know that it will require a lot of communication and frequent work between all of us.

**Static Analysis**  (due start Sprint 3)

> Use gradle build to generate the checkstyle report. Due to the high number or checkstyle errors we plan to go through and fix a couple of checkstyle errors from our own tasks or from other tasks created in the sprints by our team members.

**Continuous Integration**  (due start Sprint 3)

> We will use TravisCI as a means to review our commits. Although it is possible for our own commits to build successfully, we will troubleshoot any unsuccessful builds that occur when creating a pull request to merge our US into Development and pull requests that are created to merge from Development to master as well

## 2: During the Sprint
> Fill out the Meeting minutes during your Sprint and keep track of things. Update your Quality policies when needed, as explained in the lectures and in the Quality Policy documents on Canvas. 
I would also advise you to already fill out the Contributions section (End of sprint) as you go, to create less work at the end.

### Meeting minutes of your Daily Scrums (3 per week, should not take longer than 10 minutes):
> Add as many rows as needed and fill out the table. (Burndown starts with Sprint 2 and Travis CI starts with Sprint 3, not needed before that)

Sprint 1
|  Date  | Attendees   |Minutes   | Additional Info                                                                               |
|--------|-------------|----------|-----------------------------------------------------------------------------------------------|
|04/29/20|             |    10    |                                                                                               |
|        |Chase        |          | Assigned two tasks to work on including the splash screen fix and adding types of classes     |
|        |Edward       |          | Working on refactoring classes to make more sense of program                                  |
|        |Vignesh      |          | Creating list of belt colors to implement into program                                        |
|        |Luis         |          | Pushed US67 and 71 to repo for testing. working on editing portion of program                 |
|        |Donald       |          | US96-Task111 has been pushed to git as well as US34-Task6 for testing                         |
|--------|-------------|----------|-----------------------------------------------------------------------------------------------|
|04/30/20|             |    15    |                                                                                               |
|        |Chase        |          | Working on splash screen, causing issues finding root of error                                |
|        |Edward       |          | Pushed refactored classes to repo, still working on other US's                                | 
|        |Vignesh      |          | Working on checked out US's, will test as available                                           |
|        |Luis         |          | Still working on editing portion to change student/trainer attribtues                         |
|        |Donald       |          | US's complete, ready to help test as needed.                                                  |
|--------|-------------|----------|-----------------------------------------------------------------------------------------------|
|05/01/20|             |    15    |                                                                                               |
|        |Chase        |          | Have US's ready to test, still working on finalizing some others.                             |
|        |Edward       |          | Still working on adding trainer selection to join class                                       | 
|        |Vignesh      |          | Performed code review for US109 for Edward                                                    |
|        |Luis         |          | Hoping to have editing completed today and be ready for testing through weekend.              |
|        |Donald       |          | Helping testing and approving merge requests                                                  |

### Meeting Summary:

> Add rows as needed and add the number how many meetings they attended:

   Chase Brown :          3
   Donald Anderson:       3
   Edward Miller:         3
   Vignesh Subramanian:   3
   Luis Ramirez-Zamacona: 3
   

## 3: After the Sprint

### Sprint Review

**Screen Cast link**: https://www.youtube.com/watch?v=o_wM3yhe7qg

> Answer the following questions as a team. 

**What do you think is the value you created this Sprint?**

> We are pleased with how this sprint began to pull the project together. A lot of the features were implemented, and with a little more time we think we might have a very high final product.

**Do you think you worked enough and that you did what was expected of you?**

> At times merging got a little hairy, but we think that all in all we did what was required. The project reflects the effort we put in.

**Would you say you met the customers’ expectations? Why, why not?**

> The customer has a product that works far better than the original software. Many of the features are integrated and we think they would be pleased.

### Sprint Retrospective

> Include your Sprint retrospective here and answer the following questions in an evidence based manner as a team (I do not want each of your individuals opinion here but the team perspective). By evidence-based manner it means I want a Yes or No on each of these questions, and for you to provide evidence for your answer. That is, don’t just say "Yes we did work at a consistent rate because we tried hard"; say "we worked at a consistent rate because here are the following tasks we completed per team member and the rate of commits in our Git logs."

**Did you meet your sprint goal?**

> We came close to meeting our goal of finalizing the project. There are some lingering US's, but we are happy with where we are at.

**Did you complete all stories on your Spring Backlog?**

> We did not complete all of the stories in our sprint backlog.

**If not, what went wrong?**

> There was just a lot left to do. We made as much progress as we could.

**Did you work at a consistent rate of speed, or velocity? (Meaning did you work during the whole Sprint or did you start working when the deadline approached.)**

> Between individual assignments and this, a lot of our work was completed at the end of the week.

**Did you deliver business value?**

> Yes, we provided a far more finished product with several of the requirements implemented.

**Are there things the team thinks it can do better in the next Sprint?**

> n/a

**How do you feel at this point? Get a pulse on the optimism of the team.**

>  We are pleased with how the project turned out in the end.

### Contributions:

#### Vignesh Subramanian:

   **GitHub links to your Unit Tests (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/VigneshSprint3-UnitTests

  **GitHub links to your Code Reviews (up to 3 links):
    
    - https://github.com/amehlhase316/Mohnkuchen/pull/30
    - https://github.com/amehlhase316/Mohnkuchen/pull/25
  
**How did you contribute to Static Analysis:

    - https://github.com/amehlhase316/Mohnkuchen/tree/VigneshSprint3-UnitTests

#### Luis Ramirez-Zamacona:

  **Links to GitHub commits with main code contribution (up to 5 links):
    
    - https://github.com/amehlhase316/Mohnkuchen/tree/US67-ViewStudents
    - https://github.com/amehlhase316/Mohnkuchen/tree/US71-ViewTrainers

   **GitHub links to your Unit Tests (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/commit/259061305ecfca6fd8890b86fe89cb7dd15e9468

  **GitHub links to your Code Reviews (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/pull/34
    - https://github.com/amehlhase316/Mohnkuchen/pull/40

  **How did you contribute to Static Analysis:

    - https://github.com/amehlhase316/Mohnkuchen/commit/b95e1972df932a98275448b0ab07ed907c2b2594

 **What was your main contribution to the Quality Policy documentation?:

    - I contributed in providing my opinion in what needs to be included in our policies for the Static Analysis and CI sections for this sprint as well as reviewed reviewed any changes if any were made throughout this sprint. 

#### Chase Brown:
  **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US34-Task99-AddRooms
    - https://github.com/amehlhase316/Mohnkuchen/tree/US98-PrivilegesHotFix
    - https://github.com/amehlhase316/Mohnkuchen/tree/US97-FixSplash

  **GitHub links to your Unit Tests (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/blob/master/src/tests/Blackbox.java

  **GitHub links to your Code Reviews (up to 3 links):

    - https://github.com/amehlhase316/Mohnkuchen/pull/36#issuecomment-623027483
    - https://github.com/amehlhase316/Mohnkuchen/pull/39#issuecomment-623028709
    - https://github.com/amehlhase316/Mohnkuchen/pull/32#issuecomment-623008365

  **What was your main contribution to the Quality Policy documentation?:

    - Continued to make sure to follow QP as closely as possible throughout course of the sprint.
    
#### Don Anderson 

Contributions: **Links to GitHub commits with main code contribution (up to 5 links):

   - https://github.com/amehlhase316/Mohnkuchen/tree/US96-Task111-SetPrivateClasses
   - https://github.com/amehlhase316/Mohnkuchen/tree/US81-Task82-SaveClassRegistration

  **GitHub links to your Unit Tests (up to 3 links):

   - https://github.com/amehlhase316/Mohnkuchen/tree/US96-Task111-SetPrivateClasses-Test

 **GitHub links to your Code Reviews (up to 3 links):

   - https://github.com/amehlhase316/Mohnkuchen/pull/43
   - https://github.com/amehlhase316/Mohnkuchen/pull/35

Static analysis:
    -https://github.com/amehlhase316/Mohnkuchen/tree/US96-Task111-Static
 
**What was your main contribution to the Quality Policy documentation?:
   - Reviewed details with team.

#### Edward Miller

**Links to GitHub commits with main code contribution (up to 5 links):

- https://github.com/amehlhase316/Mohnkuchen/tree/US35-task48-SchedulerTraining
- https://github.com/amehlhase316/Mohnkuchen/tree/US109-Refactor
- https://github.com/amehlhase316/Mohnkuchen/tree/US59-Task61-AddJoinClass

**GitHub links to your Unit Tests (up to 3 links):

- https://github.com/amehlhase316/Mohnkuchen/tree/AdditionalBlackBoxTests

**GitHub links to your Code Reviews (up to 3 links):

- https://github.com/amehlhase316/Mohnkuchen/pull/29
- https://github.com/amehlhase316/Mohnkuchen/pull/31
- https://github.com/amehlhase316/Mohnkuchen/pull/41

**What was your main contribution to the Quality Policy documentation?:

- No changes made this sprint.
   
  
## 4: Checklist for you to see if you are done
- [X] Filled out the complete form from above, all fields are filled and written in full sentences
- [X] Read the kickoff again to make sure you have all the details
- [X] User Stories that were not completed, were left in the Sprint and a copy created
- [X] Your Quality Policies are accurate and up to date
- [X] **Individual** Survey was submitted **individually** (create checkboxes below -- see Canvas to get link)
  - [X] Bradley Chase Brown
  - [X] Edward Miller
  - [X] Donald Anderson
  - [X] Luis Ramirez-Zamacona
  - [X] Vignesh Subramanian
- [X] The original of this file was copied for the next Sprint (needed for all but last Sprint where you do not need to copy it anymore)
  - [X] Basic information (part 1) for next Sprint was included (meaning Spring Planning is complete)
  - [X] All User Stories have acceptance tests
  - [X] User Stories in your new Sprint Backlog have initial tasks which are in New
  - [X] You know how to proceed

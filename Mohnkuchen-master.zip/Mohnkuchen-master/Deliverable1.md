# Deliverable Information
   > Please include your answers below in a good format so it is easy for me to see. For answers to questions please use these Blockquotes. Make sure you also check the kickoff document for more details.

## 1: Basic Information (needed before you start with your Sprint -- Sprint Planning)

Topic you chose: Topic 5 - Gym Scheduling

Sprint Number: 1

Scrum Master: Chase Brown

Git Master: Edward Miller

### Sprint Planning (For Sprint 1-4)
Document your Sprint Planning here. Also check the kickoff document for more details on what needs to be done. This is just the documentation. 

**Sprint Goal:** 

During this sprint we would like to make sure all of our team members are familiarized with the
Memorandum software and are functioning as a team to complete the tasks we have assigned. Beyond the
navigation of the software, we would also like to standardize our coding practices as to maintain
a quality code base throughout the duration of this project. Lastly, we will document and diagram
the code base to help keep our project consistent.

**How many User Stories did you add to the Product Backlog:**  3

**How many User Stories did you add to this Sprint:** 3

> Answer the questions below about your Sprint Planning?

**Why did you add exactly these US?**

> US15 - It is important for our users to understand where and how to navigate our program so the icons must provide clear functionality
  US16 - We think it will be beneficial for both developers and users to know which version of the product they are currently using or working on
  US36 - Logging in is a fundamental procedure to be able to fully use our program. While we are not entirely sure we can complete it in this sprint, we would like to at least get a start so we know how we can ultimately implement it.

**Why do you think you will get them done? (details)**

> Other than US36, these seem like fairly simple implementations that we should have plenty of time to divide up between our available resources

**Do you have a rough idea what you need to do? (if the answer is no then please let me know on Slack)**

> Yes, we have a pretty good idea of what we would like to accomplish over the course of this sprint and what
it will take to accomplish it all.



## 2: During the Sprint
> Fill out the Meeting minutes during your Sprint and keep track of things. Update your Quality policies when needed, as explained in the lectures and in the Quality Policy documents on Canvas. 
I would also advise you to already fill out the Contributions section (End of sprint) as you go, to create less work at the end.

### Meeting minutes of your Daily Scrums (3 per week, should not take longer than 10 minutes):
> Add as many rows as needed and fill out the table. (Burndown starts with Sprint 2 and Travis CI starts with Sprint 3, not needed before that)

Sprint 1
| Date | Attendees   |Minutes   | Burndown Info | TravisCI info | Additional Info                                                              |
|------|-------------|----------|---------------|---------------|----------------------------------------------------------------------------- |
|4/1/20|             |    17    |               |               |                                                                              |
|      |Chase        |          | n/a           | n/a           | User stories completed, ready for testing. Ready to help and test as needed  |
|      |Edward       |          | n/a           | n/a           | Working on UML diagram, changing of icons is work in progress                | 
|      |Vignesh      |          | n/a           | n/a           | Assigned user stories are in progress                                        |
|      |Luis         |          | n/a           | n/a           | User stories completed, ready for testing. Also ready to help as needed      |
|      |Donald       |          | n/a           | n/a           | Login backend being built, expects push on Thursday. UI not worked on yet    | 
|------|-------------|----------|---------------|---------------|----------------------------------------------------------------------------- |
|4/2/20|             |    8     |               |               |                                                                              |
|      |Chase        |          | n/a           | n/a           | No new changes. Will be testing US's as they are completed                   |
|      |Edward       |          | n/a           | n/a           | UML completed and ready for review. Icons are coming along                   | 
|      |Vignesh      |          | n/a           | n/a           | Working on User Stories, ideally complete by Saturday                        |
|      |Luis         |          | n/a           | n/a           | Ready to help with testing as needed, tested US9                             |
|      |Donald       |          | n/a           | n/a           | First push of login backend had small errors, needs to correct before testing|
|------|-------------|----------|---------------|---------------|----------------------------------------------------------------------------- |
|4/3/20|             |    11    |               |               |                                                                              |
|      |Chase        |          | n/a           | n/a           | Have tested/reviewed US 8,10 and ready to test more when needed              |
|      |Edward       |          | n/a           | n/a           | US43 completed, US30 in progress, will be ready for testing this weekend     | 
|      |Vignesh      |          | n/a           | n/a           | Had an issue when pushing files, not the correct ones. Sought help from group|
|      |Luis         |          | n/a           | n/a           | Will help test Chase and Donald's US's over the next couple of days          |
|      |Donald       |          | n/a           | n/a           | New push of login system ready to review, ready to help as necessary         |

### Meeting Summary:

> Add rows as needed and add the number how many meetings they attended:

   Chase Brown :          3
   Donald Anderson:       3 
   Edward Miller:         3
   Vignesh Subramanian:   3
   Luis Ramirez-Zamacona: 3
   
   Note: If member was unable to attend meeting directly, they were filled in via slack and provided an update of their work there as well.

## 3: After the Sprint

### Sprint Review

**Screen Cast link**: https://www.youtube.com/watch?v=neOVeX5DK4M&feature=youtu.be

> Answer the following questions as a team. 

**What do you think is the value you created this Sprint?**

> The foundation of our Dojo software has been laid. We were able to eliminate several bugs that were detrimental to the operation of the software and begin to reshape the UI so that it matches
  what the software will ultimately look like.

**Do you think you worked enough and that you did what was expected of you?**

> We completed the User Stories we thought that we would, and the two that are not complete are a continued work in progress. The merging of our branches was not initially handled how it 

**Would you say you met the customers’ expectations? Why, why not?**

> Yes, we did meet the customers' expectation. We have a product that is beginning to take shape and already has significantly fewer errors than it did one week ago.

### Sprint Retrospective

> Include your Sprint retrospective here and answer the following questions in an evidence based manner as a team (I do not want each of your individuals opinion here but the team perspective). By evidence-based manner it means I want a Yes or No on each of these questions, and for you to provide evidence for your answer. That is, don’t just say "Yes we did work at a consistent rate because we tried hard"; say "we worked at a consistent rate because here are the following tasks we completed per team member and the rate of commits in our Git logs."

**Did you meet your sprint goal?**

> Yes, we did meet our sprint goal. We all have a good understanding of the software and have a foundation set for the Dojo software.

**Did you complete all stories on your Spring Backlog?**

> There were two User Stories not completed entirely (US36 and US13), but that was expected.

**If not, what went wrong?**

> US36 is a complex addition of a login system that we expected to take longer than this initial sprint. We implemented the backend of the system and will be working on UI next sprint.
  US13 is one that we also expect to evolve as we proceed throughout the project. It includes several sub-tasks that we expect to work on as we know more about our implementation.

**Did you work at a consistent rate of speed, or velocity? (Meaning did you work during the whole Sprint or did you start working when the deadline approached.)**

> Yes we did work at a consistent rate of speed, as demonstrated by our commits in our repo. In the future, we need to be better about updating our taskboard as we complete tasks.
  Our burndown will reflect that we completed several tasks on Sunday, but that is inaccurate. We were completing and testing User Stories throughout the week, but we neglected
  updating as we finished. It is a learning opportunity that we will imrpove on.


**Did you deliver business value?**

> Yes, we did add business value. We have already made the program more useable by completing some of the basic functionality User Stories. We gave the software a name and a logo,
  and we have the foundation set to have a login system completed at the end of our next Sprint.

**Are there things the team thinks it can do better in the next Sprint?**

> As mentioned, we can update the Taiga board more consistently. We also did not commit our User Stories correctly at first and were pushing our completed tasks directly to the
  Development branch when they were ready for testing. We quickly realized that we needed to push the User Story branch, test that, and then merge them onto Development once completed.
  We now have a firm grasp on the process.

**How do you feel at this point? Get a pulse on the optimism of the team.**

> We were able to communicate frequently throughout the week and complete our User Stories. Help was offered as needed. We feel like we have a decent grasp on the Memorandum software and
  using git/github as well as Taiga. We think things will be more fluent in our next sprint.

### Contributions:

> In this section I want you to point me to your main contributions (each of you individually). Some of the topcs are not needed for the first deliverables (you should know which things you should have done in this Sprint, if you don't then you have probably missed something):

#### Luis Ramirez-Zamacona:
  **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US8-FixTerminate
    - https://github.com/amehlhase316/Mohnkuchen/tree/US10-FixMinimize
    - https://github.com/amehlhase316/Mohnkuchen/tree/US11-FixLanguage
 
 **What was your main contribution to the Quality Policy documentation?:

    - I provided reminders as to how to name our branches during meetings and I created my branches based on the Quality Policy documentation. As a team we agreed to base our Quality Policy document on our SER316 notes, but as far as actually creating the Quality Policy documentation file, all credit goes to Chase.

#### Chase Brown:
  **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US16-UpdateVersion
    - https://github.com/amehlhase316/Mohnkuchen/tree/US9-SplashScreen

 **What was your main contribution to the Quality Policy documentation?:

    - I helped put together the Quality Document using references from in class on how we should maintain our code. Made sure to seek input from teammates before committing to our final document.

#### Don Anderson djande23
 **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US36

 **What was your main contribution to the Quality Policy documentation?:
    
    -Reviewed, discussed the needed components for our Quality Policy. We decided on them together as a team in a slack call.

#### Vignesh Subramanian
 **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US13
    - https://github.com/amehlhase316/Mohnkuchen/tree/US12

 **What was your main contribution to the Quality Policy documentation?:
    
    - I reviewed final document.

#### Edward Miller
 **Links to GitHub commits with main code contribution (up to 5 links):

    - https://github.com/amehlhase316/Mohnkuchen/tree/US15-FixIcons
    - https://github.com/amehlhase316/Mohnkuchen/tree/US43-CreateClassDiagram
    - https://github.com/amehlhase316/Mohnkuchen/tree/US30-FixPreferencesBug

 **What was your main contribution to the Quality Policy documentation?:
    
    - Reviewed class documentation and final quality policy document.
  
## 4: Checklist for you to see if you are done
- [X] Filled out the complete form from above, all fields are filled and written in full sentences
- [X] Read the kickoff again to make sure you have all the details
- [X] User Stories that were not completed, were left in the Sprint and a copy created
- [X] Your Quality Policies are accurate and up to date
- [X] **Individual** Survey was submitted **individually** (create checkboxes below -- see Canvas to get link)
  - [X] Bradley Chase Brown
  - [X] Edward Miller
  - [X] Donald Anderson
  - [X] Luis Ramirez-Zamacona
  - [X] Vignesh Subramanian
- [X] The original of this file was copied for the next Sprint (needed for all but last Sprint where you do not need to copy it anymore)
  - [X] Basic information (part 1) for next Sprint was included (meaning Spring Planning is complete)
  - [X] All User Stories have acceptance tests
  - [X] User Stories in your new Sprint Backlog have initial tasks which are in New
  - [X] You know how to proceed

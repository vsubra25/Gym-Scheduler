package tests;

import main.java.memoranda.User;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class Whitebox {

    User user1;
    User user2;

    /**
     * Using User.java to create a user named
     * Jackie Chan to test the login method.
     * @author Luis Ramirez
     * @throws Exception Exception
     */
    @Before
    public void setUp() throws Exception {
        user1 = new User("JChan", "MartialArts", 
                "Jackie", "Chan", "123456789",
                "jackie@chan.com", 13, 3, 1);
    }
    
    /**
     * Using User.java to create a user named
     * Bruce Lee to test the login method.
     * @author Luis Ramirez
     * @throws Exception Exception
     */
    @Before
    public void setUp2() throws Exception {
        user2 = new User("BLee", "WingChun", 
                "Bruce", "Lee", "012345678",
                "bruce@lee.com", 1, 1, 1);
    }

    /**
     * This tests that the login method returns
     * true. This test will pass since the login
     * @author Luis Ramirez
     * @throws Exception Exception
     */
    @Test
    public void login1() {
        assertEquals(true, user1.login("JChan", 
                "MartialArts"));
    }
    
    /**
     * This tests that the login method returns
     * false. This test will pass since the login
     * credentials do not match user2 credentials.
     * @author Luis Ramirez
     * @throws Exception Exception
     */
    @Test
    public void login2() {
        assertEquals(false, user2.login("BLee", "Wingchun"));
    }
    
    /**
     * This tests the getname method. This test
     * is expected to pass with user1 first name
     * and last name returning as intended.
     * @author Luis Ramirez
     * @throws Exception Exception
     */
    @Test
    public void getName() {
        assertEquals("Jackie Chan", user1.getname());
    }
    
    /**
     * This tests the getaccesslevel method. This
     * test is expected to pass with user2's access
     * level returning as intended.
     * @author Luis Ramirez
     * @throws Exception Exception
     */
    @Test
    public void getAccessLevel() {
        assertEquals(1, user2.getaccesslevel());
    }
}
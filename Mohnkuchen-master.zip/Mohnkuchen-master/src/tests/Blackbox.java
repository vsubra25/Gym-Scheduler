package tests;

import main.java.memoranda.ui.ClassesDialog;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import main.java.memoranda.User;
import main.java.memoranda.Userlist;


public class Blackbox {
    // Instantiate some classes for test
    // @author Edward Miller
    private User userTest = new User("Butter","Waffles","Edward","Miller", "phn", "eml", 4, 7, 1);
    private Userlist test = new Userlist();

    // This test ensure the trainer log in is accurate
    // @author Edward Miller
    @Test
    public void usOwnerLogin() throws IOException {
        Userlist userlist = new Userlist();
        userlist.ownerLogin("test2", "test3", 4);
        assertEquals("Checking login", userlist, userlist);
    }

    // This test ensure the trainer log in is accurate
    // @author Edward Miller
    @Test
    public void us71TrainerLogin() throws IOException {
        Userlist userlist = new Userlist();
        userlist.trainerLogin("test", "test1", 3);
        assertEquals("Checking login", userlist, userlist);
    }

    // This tests ensures user list contains the correct information
    // @author Edward Miller
    @Test
    public void us67testViewStudentInfo() throws IOException {
        Userlist userlist = new Userlist();
        userlist.addUser("Rocket", "Orange", "Book", "Chair", "8676309", "@yahoo", 2, 4);
        assertEquals("Check user list", userlist, userlist);
    }

    // This test ensures the new icon for view students properly exists
    // @author - Edward Miller
    @Test
    public void us71ViewTrainerButtonTest() throws IOException {
        File viewButtonIcon = new File("src/main/resources/ui/icons/jnotes16.png");
        assert(viewButtonIcon.exists());
    }

    //This test verifies that the event icons are included when the program is started
    //@author - Chase Brown
    @Test
    public void Us59Task89ChangeIconsTest() throws IOException {
        File classIcon = new File("src/main/resources/ui/icons/dojoClass.png");
        File instructorIcon = new File("src/main/resources/ui/icons/dojoInstructors.png");
        File noteIcon = new File("src/main/resources/ui/icons/dojoNote.png");
        File roomIcon = new File("src/main/resources/ui/icons/dojoRoom.png");
        File taskIcon = new File("src/main/resources/ui/icons/dojoTasks.png");
        assert(classIcon.exists());
        assert(instructorIcon.exists());
        assert(noteIcon.exists());
        assert(roomIcon.exists());
        assert(taskIcon.exists());
    }
    //This test verifies that the joinClass icon exists when the program is started
    //@author - Chase Brown
    @Test
    public void Us59Task61AddJoinClass() throws IOException {
        File joinIcon = new File("src/main/resources/ui/icons/dojoJoin.png");
        assert(joinIcon.exists());
    }
    //This test verifies that the public class icon exists when the program is started
    //@author - Chase Brown
    @Test
    public void Us59Task60AddScheduleClass() throws IOException {
        File scheduleIcon = new File("src/main/resources/ui/icons/dojoPublic.png");
        assert(scheduleIcon.exists());
    }
    //This test verifies that the About Dojo logo is correct on program startup
    //@author - Chase Brown
    @Test
    public void Us79AboutDojologo() throws IOException {
        File aboutLogo = new File("src/main/resources/ui/memoranda.png");
        assert(aboutLogo.exists());
    }
    //This test verifies that the 'Room' option is available when user selects a class
    //@author - Chase Brown
    @Test
    public void US34AddRooms() {
        Frame frame = new Frame();
        ClassesDialog ed = new ClassesDialog(frame, "test");
        equals("Room", ed.roomTextField.getText());
    }

    private void equals(String room, String text) {
    }

    //Verified dojo logo still works and starts in correct place
    //@author - Chase Brown
    @Test
    public void Us97FixSplashScreen() throws IOException {
        File aboutLogo = new File("src/main/resources/ui/memoranda.png");
        assert(aboutLogo.exists());
    }


    //This test verifies that the priveleges are correct for the owner
    //@author - Chase Brown
    @Test
    public void US98OwnerPrivileges() {
        equals(userTest.login("Butter", "Waffles"));
    }

    // UserList
    // @author Edward Miller
    @Test
    public void testSize() {
        assertEquals("Check size of list", 0, test.size());
    }

    //UserList
    // @author Edward Miller
    @Test
    public void testAdd() throws IOException {
        test.addUser("Donald", "Luis", "apple", "Cloud", "8676309", "@aol", 6, 5);
        test.addUser("Chase", "Luis", "orange", "Tifa", "2353255", "@aol", 9, 1);
        test.addUser("Vignesh", "Luis", "drow", "Aerith", "9327434", "@aol", 3, 8);
        assertEquals("Check list addition", 3, test.size());
    }

    // User
    // @author Edward Miller
    @Test
    public void getName()
    {
        assertEquals("Check size of list", "Edward Miller", userTest.getname());
    }

    // User
    // @author Edward Miller
    @Test
    public void getUserId()
    {
        assertEquals("Check for proper user ID", 1, userTest.getuserID() );
    }
}
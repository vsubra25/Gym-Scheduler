package main.java.memoranda.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import main.java.memoranda.Userlist;
import main.java.memoranda.util.Local;

public class ViewTrainersDialog extends JDialog {
    JPanel dialogTitlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel header = new JLabel();
    JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
    JButton closeB = new JButton();
    public boolean CANCELLED = true;
    Userlist userlist = new Userlist();

    public ViewTrainersDialog(Frame frame, String title) {
        super(frame, title, true);
        try {
            jbInit();
            pack();
        }
        catch (Exception ex) {
            new ExceptionDialog(ex);
            ex.printStackTrace();
        }
    }

    /**
     * setup user interface and init dialog
     */
     
    void jbInit() throws Exception {
        this.setResizable(false);
        dialogTitlePanel.setBackground(Color.WHITE);
        dialogTitlePanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        header.setFont(new java.awt.Font("Dialog", 0, 20));
        header.setForeground(new Color(0, 0, 124));
        header.setText(Local.getString("View Trainers"));
        header.setIcon(new ImageIcon(main.java.memoranda.ui.AddResourceDialog.class.getResource(
            "/ui/icons/resource48.png")));
        dialogTitlePanel.add(header);
        this.getContentPane().add(dialogTitlePanel, BorderLayout.NORTH);
        
        userlist.loadlist();
        String header[] = { "Name", "Phone", "Email Address", "Belt Color" };
        String userInfo[][] = new String[userlist.size()][4];
        int tableIndex = 0;
        
        for(int i = 0; i < userlist.size(); i++) {
            if(userlist.list.get(i).getaccesslevel() == 1) {
                for(int j = 0; j < 4; j++) {
                    if(j == 0) {
                        userInfo[tableIndex][j] = userlist.list.get(i).getname();
                    } else if(j == 1) {
                        userInfo[tableIndex][j] = userlist.list.get(i).getphone();
                    } else if(j == 2) {
                        userInfo[tableIndex][j] = userlist.list.get(i).getemail();
                    } else if(j == 3) {
                        userInfo[tableIndex][j] = String.valueOf(userlist.list.get(i).getUsertype());
                        tableIndex++;
                    }
                }
            }
        }
        
        JTable table = new JTable(userInfo, header);
        JScrollPane scrollPane = new JScrollPane(table);
        
        this.getContentPane().add(scrollPane, BorderLayout.CENTER);
        
        closeB.setMaximumSize(new Dimension(100, 26));
        closeB.setMinimumSize(new Dimension(100, 26));
        closeB.setPreferredSize(new Dimension(100, 26));
        closeB.setText(Local.getString("Close"));
        closeB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                closeB_actionPerformed(e);
            }
        });
        
        buttonsPanel.add(closeB);
        this.getContentPane().add(buttonsPanel, BorderLayout.SOUTH);
    }

    /**
     * close the dialog window
     */
     
    void closeB_actionPerformed(ActionEvent e) {
        CANCELLED = false;
        this.dispose();
    }
}
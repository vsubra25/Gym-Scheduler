package main.java.memoranda.ui;

import javax.swing.*;

public class FailPanel extends JFrame{
    JPanel failPanel;
    JLabel failLabel;
    public JButton failButton;

    public FailPanel(){
        failPanel = new JPanel();
        failLabel = new JLabel("Incorrect username or password");
        failButton = new JButton("Ok");
        setSize(250,150);
        setLocationRelativeTo(null);
        failPanel.add(failLabel);
        failPanel.add(failButton);
        failPanel.setLayout (null);
        failLabel.setBounds(20,10,200,50);
        failButton.setBounds(75, 50, 80, 40);
        getContentPane().add(failPanel);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}

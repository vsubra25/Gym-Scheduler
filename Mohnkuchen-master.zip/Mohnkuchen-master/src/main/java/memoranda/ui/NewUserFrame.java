package main.java.memoranda.ui;

import java.io.IOException;
import javax.swing.*;
import javax.swing.border.Border;
import main.java.memoranda.Register;
import main.java.memoranda.Userlist;

public class NewUserFrame extends JFrame{

    JPanel loginPanel;
    public JTextField userText;
    public JTextField passText;
    public JTextField firstNameText;
    public JTextField lastNameText;
    public JTextField phoneText;
    public JTextField emailText;
    public JButton newUserButton;
    public JComboBox<String> beltBox;
    public JComboBox<String> accessBox;

    JLabel usernameLabel;
    JLabel passwordLabel;
    JLabel firstNameLabel;
    JLabel lastNameLabel;
    JLabel phoneLabel;
    JLabel emailLabel;
    JLabel beltLabel;
    JLabel accessLabel;

    String title = "Register";
    Border border = BorderFactory.createTitledBorder(title);

    String beltChoices[] = {
            "White",
            "Yellow",
            "Orange",
            "Purple",
            "Blue",
            "Blue Stripe",
            "Green",
            "Green Stripe",
            "Brown 1",
            "Brown 2",
            "Brown 3",
            "Black 1",
            "Black 2",
            "Black 3"
    };

    String accessChoices[] = {
            "Member",
            "Trainer",
    };

    public NewUserFrame() {
        beltBox = new JComboBox<String>(beltChoices);
        accessBox = new JComboBox<String>(accessChoices);
        loginPanel = new JPanel();
        loginPanel.setBorder(border);
        userText = new JTextField(15);
        passText = new JTextField(15);
        firstNameText = new JTextField(15);
        lastNameText = new JTextField(15);
        emailText = new JTextField(15);
        phoneText = new JTextField(15);
        newUserButton = new JButton("Register");
        usernameLabel = new JLabel("Username");
        passwordLabel = new JLabel("Password");
        firstNameLabel = new JLabel("First Name");
        lastNameLabel = new JLabel("Last Name");
        phoneLabel = new JLabel("Phone");
        emailLabel = new JLabel("Email");
        beltLabel = new JLabel("Belt");
        accessLabel = new JLabel("Access Level");

        setSize(300, 400);
        setLocationRelativeTo(null);
        loginPanel.setLayout(null);

        userText.setBounds(100, 30, 150, 20);
        passText.setBounds(100, 65, 150, 20);
        firstNameText.setBounds(100, 110, 150, 20);
        lastNameText.setBounds(100, 148, 150, 20);
        phoneText.setBounds(100, 186, 150, 20);
        emailText.setBounds(100, 224, 150, 20);
        beltBox.setBounds(100, 262, 150, 20);
        accessBox.setBounds(100, 300, 150, 20);

        newUserButton.setBounds(110, 330, 100, 20);
        usernameLabel.setBounds(20, 30, 80, 20);
        passwordLabel.setBounds(20, 65, 80, 20);
        firstNameLabel.setBounds(20, 110, 80, 20);
        lastNameLabel.setBounds(20, 148, 80, 20);
        phoneLabel.setBounds(20, 186, 80, 20);
        emailLabel.setBounds(20, 224, 80, 20);
        beltLabel.setBounds(20,262,150,20);
        accessLabel.setBounds(20,300,150,20);

        loginPanel.add(userText);
        loginPanel.add(passText);
        loginPanel.add(firstNameText);
        loginPanel.add(lastNameText);
        loginPanel.add(phoneText);
        loginPanel.add(emailText);
        loginPanel.add(beltBox);
        loginPanel.add(accessBox);

        loginPanel.add(newUserButton);
        loginPanel.add(usernameLabel);
        loginPanel.add(passwordLabel);
        loginPanel.add(firstNameLabel);
        loginPanel.add(lastNameLabel);
        loginPanel.add(phoneLabel);
        loginPanel.add(emailLabel);
        loginPanel.add(beltLabel);
        loginPanel.add(accessLabel);

        getContentPane().add(loginPanel);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    public void addUser(Userlist userlist){
        newUserButton.addActionListener(e -> {
            String unm, pswd, fn, ln, phone, email;
            int belt = 0;
            int access = 0;
            setVisible(false);
            unm = userText.getText();
            pswd = passText.getText();
            fn = firstNameText.getText();
            ln = lastNameText.getText();
            phone = phoneText.getText();
            email = emailText.getText();
            Userlist u = new Userlist();
            Register r = new Register();
            r.registerUser(u.list.size() + 1);
            switch (beltBox.getSelectedItem().toString()) {
                case "White":
                    belt = 0;
                    break;
                case "Yellow":
                    belt = 1;
                    break;
                case "Orange":
                    belt = 2;
                    break;
                case "Purple":
                    belt = 3;
                    break;
                case "Blue":
                    belt = 4;
                    break;
                case "Blue Stripe":
                    belt = 5;
                    break;
                case "Green":
                    belt = 6;
                    break;
                case "Green Stripe":
                    belt = 7;
                    break;
                case "Brown 1":
                    belt = 8;
                    break;
                case "Brown 2":
                    belt = 9;
                    break;
                case "Brown 3":
                    belt = 10;
                    break;
                case "Black 1":
                    belt = 11;
                    break;
                case "Black 2":
                    belt = 12;
                    break;
                case "Black 3":
                    belt = 13;
                    break;
            }

            switch (accessBox.getSelectedItem().toString()) {
                case "Member":
                    access = 0;
                    break;
                case "Trainer":
                    access = 1;
                    break;
            }

            try {
                userlist.addUser(unm,pswd,fn,ln, phone, email, belt, access);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }
}

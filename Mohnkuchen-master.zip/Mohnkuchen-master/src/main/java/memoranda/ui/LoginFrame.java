package main.java.memoranda.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.border.Border;

public class LoginFrame extends JFrame {
    JPanel loginPanel;
    public JButton loginButton;
    public JTextField userText;
    public JTextField passText;
    JLabel usernameLabel;
    JLabel passwordLabel;

    public LoginFrame() {
        String title = "Login to Dojo";
        Border border = BorderFactory.createTitledBorder(title);
        loginButton = new JButton("Login");
        loginPanel = new JPanel();
        loginPanel.setBorder(border);
        userText = new JTextField(15);
        passText = new JPasswordField(15);
        usernameLabel = new JLabel("Username");
        passwordLabel = new JLabel("Password");

        setSize(300,180);
        setLocationRelativeTo(null);
        loginPanel.setLayout (null);

        userText.setBounds(100,30,150,20);
        passText.setBounds(100,65,150,20);
        loginButton.setBounds(110,100,100,20);
        usernameLabel.setBounds(20,28,80,20);
        passwordLabel.setBounds(20,63,80,20);

        loginPanel.add(loginButton);
        loginPanel.add(userText);
        loginPanel.add(passText);
        loginPanel.add(usernameLabel);
        loginPanel.add(passwordLabel);

        getContentPane().add(loginPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}

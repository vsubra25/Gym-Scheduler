package main.java.memoranda;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Register {
    private class Customer{
        int userID;
        Customer next;
        Customer last;

        public Customer(int a){
            userID=a;
        }

        public void setNext(Customer next) {
            this.next = next;
        }

        public void setLast(Customer last) {
            this.last = last;
        }

        public void clearNext(){
            next=null;
        }

        public void setUserID(int userID) {
            this.userID = userID;
        }
    }
    private int maxCustomers =20;
    private int currentRegistered;
    Customer head; //head is always the trainer.
    Customer tail;


    public Register(){
        head=new Customer(0);
        tail=head;
    }
    public void setTrainer(int n){
        head.setUserID(n);
    }

    public void registerUser(int userID){
        if (currentRegistered<maxCustomers){
            Customer temp = new Customer(userID);
            tail.setNext(temp);
            tail=tail.next;
            currentRegistered++;
        }
    }
    public boolean changeMaxCustomers(int n){
        if(currentRegistered<n) {
            maxCustomers = n;
            return true;
        }
        return false;
    }
    public int slotsAvailable(){
        return maxCustomers-currentRegistered;
    }

    //temporary add to help debug
    private List<User> list = new ArrayList<User>();

    private void loadRegisterList() throws IOException {
        Path path = Paths.get("src/main/resources/userInfo/userInfo.txt");
        String sep = path.toString();
        BufferedReader reader = new BufferedReader(new FileReader(sep));
        String str = reader.readLine();
        while(str != null) {
            String[] info = str.split("\\s+");
            main.java.memoranda.User newuser=new main.java.memoranda.User(info[0], info[1], info[2], info[3], info[4], info[5], Integer.parseInt(info[6]), Integer.parseInt(info[7]), Integer.parseInt(info[8]));
            list.add(newuser);
            str = reader.readLine();
        }
    }
    public boolean removeUser(int userId){
        boolean removed=false;
        Customer temp =head;
        while(temp.userID!=tail.userID){
            if(temp.userID==userId){
                popCustomer(temp);
                removed=true;
            }
            else{
                temp = temp.next;
            }
        }
        return removed;
    }
    private void popCustomer(Customer n){
        n.last.setNext(n.next);
        n.next.setNext(n.last);
    }
}

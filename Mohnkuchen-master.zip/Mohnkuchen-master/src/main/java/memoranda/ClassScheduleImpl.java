/**
 * ClassScheduleImpl.java
 * Created on 08.03.2003, 13:20:13 Alex
 * Package: net.sf.memoranda
 *
 * @author Alex V. Alishevskikh, alex@openmechanics.net
 * Copyright (c) 2003 Memoranda Team. http://memoranda.sf.net
 */
package main.java.memoranda;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import main.java.memoranda.date.CalendarDate;
import main.java.memoranda.util.Local;
import nu.xom.Attribute;
import nu.xom.Element;

/**
 *
 */
/*$Id: ClassScheduleImpl.java,v 1.9 2004/10/06 16:00:11 ivanrise Exp $*/
public class ClassScheduleImpl implements ClassSchedule, Comparable {
    private int regLimit;
    private Element _elem = null;

    /**
     * Constructor for ClassScheduleImpl.
     */
    public ClassScheduleImpl(Element elem) {
        regLimit = 20;
        _elem = elem;
        if (_elem.getAttribute("Existing") == null) {
            //if element named "Existing" does not exist, initialize it.
            _elem.addAttribute(new Attribute("Existing", "True"));
            _elem.addAttribute(new Attribute("Trainer", "0"));
            _elem.addAttribute(new Attribute("RegisteredUsers", "0"));
            _elem.addAttribute(new Attribute("RoomNumber", "0"));
            _elem.addAttribute(new Attribute("BeltMin", "0"));
            _elem.addAttribute(new Attribute("Private", "0"));
            for (int i = 1; i < 21; i++) {
                String title = "Student" + i;
                _elem.addAttribute(new Attribute(title, "Null"));
            }
        }
    }


    /**
     * @see ClassSchedule#getHour()
     */
    public int getHour() {
        return new Integer(_elem.getAttribute("hour").getValue()).intValue();
    }

    /**
     * @see ClassSchedule#getMinute()
     */
    public int getMinute() {
        return new Integer(_elem.getAttribute("min").getValue()).intValue();
    }

    public String getTimeString() {
        return Local.getTimeString(getHour(), getMinute());
    }


    /**
     * @see ClassSchedule#getText()
     */
    public String getText() {
        return _elem.getValue();
    }

    /**
     * @see ClassSchedule#getContent()
     */
    public Element getContent() {
        return _elem;
    }

    /**
     * @see ClassSchedule#isRepeatable()
     */
    public boolean isRepeatable() {
        return getStartDate() != null;
    }

    /**
     * @see ClassSchedule#getStartDate()
     */
    public CalendarDate getStartDate() {
        Attribute a = _elem.getAttribute("startDate");
        if (a != null) return new CalendarDate(a.getValue());
        return null;
    }

    /**
     * @see ClassSchedule#getEndDate()
     */
    public CalendarDate getEndDate() {
        Attribute a = _elem.getAttribute("endDate");
        if (a != null) return new CalendarDate(a.getValue());
        return null;
    }

    /**
     * @see ClassSchedule#getPeriod()
     */
    public int getPeriod() {
        Attribute a = _elem.getAttribute("period");
        if (a != null) return new Integer(a.getValue()).intValue();
        return 0;
    }

    /**
     * @see ClassSchedule#getId()
     */
    public String getId() {
        Attribute a = _elem.getAttribute("id");
        if (a != null) return a.getValue();
        return null;
    }

    /**
     * @see ClassSchedule#getRepeat()
     */
    public int getRepeat() {
        Attribute a = _elem.getAttribute("repeat-type");
        if (a != null) return new Integer(a.getValue()).intValue();
        return 0;
    }

    /**
     * @see ClassSchedule#getTime()
     */
    public Date getTime() {
        //Deprecated methods
        //Date d = new Date();
        //d.setHours(getHour());
        //d.setMinutes(getMinute());
        //d.setSeconds(0);
        //End deprecated methods

        Date d = new Date(); //Revision to fix deprecated methods (jcscoobyrs) 12-NOV-2003 14:26:00
        Calendar calendar = new GregorianCalendar(Local.getCurrentLocale()); //Revision to fix deprecated methods (jcscoobyrs) 12-NOV-2003 14:26:00
        calendar.setTime(d); //Revision to fix deprecated methods (jcscoobyrs) 12-NOV-2003 14:26:00
        calendar.set(Calendar.HOUR_OF_DAY, getHour()); //Revision to fix deprecated methods (jcscoobyrs) 12-NOV-2003 14:26:00
        calendar.set(Calendar.MINUTE, getMinute()); //Revision to fix deprecated methods (jcscoobyrs) 12-NOV-2003 14:26:00
        calendar.set(Calendar.SECOND, 0); //Revision to fix deprecated methods (jcscoobyrs) 12-NOV-2003 14:26:00
        d = calendar.getTime(); //Revision to fix deprecated methods (jcscoobyrs) 12-NOV-2003 14:26:00
        return d;
    }

    /**
     * @see ClassSchedule#getWorkinDays()
     */
    public boolean getWorkingDays() {
        Attribute a = _elem.getAttribute("workingDays");
        if (a != null && a.getValue().equals("true")) return true;
        return false;
    }

    public int compareTo(Object o) {
        ClassSchedule classSchedule = (ClassSchedule) o;
        return (getHour() * 60 + getMinute()) - (classSchedule.getHour() * 60 + classSchedule.getMinute());
    }

    /**
     *
     * @param n
     * @return
     */
    public boolean registerUser(int n, int belt) {
        int required = Integer.parseInt(_elem.getAttributeValue("BeltMin"));
        boolean registered = true;
        if (isRegistered(n)) {
            return true;
        }
        if (numRegistered() < 20 && belt >= required) {
            for (int i = 1; i < 21; i++) {
                String title = "Student" + i;
                if (_elem.getAttributeValue(title) == "Null") {
                    _elem.getAttribute(title).setValue(Integer.toString(n));
                    _elem.getAttribute("RegisteredUsers").setValue(Integer.toString(numRegistered()+1));
                    return true;
                }
            }
        }
        else {
            registered = false;
        }
        return registered;
    }

    /**
     *
     * @param n
     * @return
     */
    public boolean isRegistered(int n) {
        for (int i = 1; i < 21; i++) {
            String title = "Student" + i;
            if (_elem.getAttributeValue(title) != "Null") {
                if (n == Integer.parseInt(_elem.getAttributeValue(title))) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     *
     * @param n
     */
    public void deRegister(int n) {
        if (isRegistered(n)) {
            String comp = Integer.toString(n);
            for (int i = 1; i < 21; i++) {
                String title = "Student" + i;
                if (comp == _elem.getAttribute(title).toString()) {
                    _elem.getAttribute(title).setValue("Null");
                    int c = numRegistered();
                    c--;
                    _elem.getAttribute("RegisteredUsers").setValue(Integer.toString(c));
                    break;
                }

            }
        }
    }

    /**
     *
     * @param n
     */
    public void setRoom(int n) {
        _elem.getAttribute("RoomNumber").setValue(Integer.toString(n));
    }

    /**
     * 
     * @return
     */
    public int getRoom(){
        return Integer.parseInt(_elem.getAttributeValue("RoomNumber"));
    }

    /**
     *
     * @return
     */
    public int numRegistered() {
        return Integer.parseInt(_elem.getAttribute("RegisteredUsers").getValue());
    }

    /**
     *
     * @param n
     */
    public void setTrainer(int n) {
        _elem.getAttribute("Trainer").setValue(Integer.toString(n));
    }

    public int getTrainer() {
        return Integer.parseInt(_elem.getAttribute("Trainer").getValue());
    }

    /**
     *
     * @param n
     * @return
     */
    public boolean makePrivate(int n) {
        if (n >= numRegistered()) {
            regLimit = n;
            _elem.getAttribute("Private").setValue("1");
            return true;
        }
        return false;
    }

    /**
     *
     * @param n
     * @return
     */
    public boolean makePublic(int n) {
        if (n >= numRegistered()) {
            regLimit = n;
            _elem.getAttribute("Private").setValue("0");
            return true;
        }
        return false;
    }

    /**
     *
     * @return
     */
    public boolean isPrivate() {
        if (_elem.getAttribute("Private").getValue() == "0") {
            return false;
        } else {
            return true;
        }
    }
    public void setBeltRequirement(int n){
        _elem.getAttribute("BeltMin").setValue(Integer.toString(n));

    }

}

package main.java.memoranda;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import main.java.memoranda.ui.FileExportDialog;


public class Userlist {
    public List<main.java.memoranda.User> list = new ArrayList<main.java.memoranda.User>();
    private main.java.memoranda.User currentuser,guest = new main.java.memoranda.User("guest","password","guest","mcguesterson",
            "99999999", "guest@guest.com", 0, 0, 0);


   public Userlist() {
       currentuser = guest;
    }
    public boolean ownerLogin(String usn,String pass, int accessLevel){
       for(int i=0;i<list.size();i++){
           //owner access is level 2
           if(list.get(i).Password.equals(pass) && list.get(i).Username.equals(usn) && list.get(i).accesslevel == 2) {
               currentuser = list.get(i);
               return true;
           }
       }
       return false;
    }
    public boolean userLogin(String usn,String pass, int accessLevel){
        for(int i=0;i<list.size();i++){
            //owner access is level 2
            if(list.get(i).Password.equals(pass) && list.get(i).Username.equals(usn) && list.get(i).accesslevel == 0) {
                currentuser = list.get(i);
                return true;
            }
        }
        return false;
    }
    public boolean trainerLogin(String usn,String pass, int accessLevel){
        for(int i=0;i<list.size();i++){
            //owner access is level 2
            if(list.get(i).Password.equals(pass) && list.get(i).Username.equals(usn) && list.get(i).accesslevel == 1) {
                currentuser = list.get(i);
                return true;
            }
        }
        return false;
    }
    public void addUser(String uname, String pass,String fname, String lname, String phone, String email, int belt, int access) throws IOException {
        Path path = Paths.get("src/main/resources/userInfo/userInfo.txt");
        String sep = path.toString();
        BufferedWriter out = new BufferedWriter(new FileWriter(sep, true));
        int idn=list.size();
        out.write(uname + " " + pass + " " + fname + " " + lname + " " + phone + " " + email + " " + belt + " " + access + " " + idn);
        out.newLine();
        out.close();
        main.java.memoranda.User newuser=new main.java.memoranda.User(uname,pass,fname,lname, phone,email, belt, access, idn);
        list.add(newuser);
    }
    public void loadlist() throws IOException {
        Path path = Paths.get("src/main/resources/userInfo/userInfo.txt");
        String sep = path.toString();
        BufferedReader reader = new BufferedReader(new FileReader(sep));
        String str = reader.readLine();
        while(str != null) {
            String[] info = str.split("\\s+");
            main.java.memoranda.User newuser=new main.java.memoranda.User(info[0], info[1], info[2], info[3], info[4], info[5], Integer.parseInt(info[6]), Integer.parseInt(info[7]), Integer.parseInt(info[8]));
            list.add(newuser);
            str = reader.readLine();
        }
    }
    public String changeAccessLevel(int userid,int newlevel){
       if(currentuser.getaccesslevel()>2){
           list.get(userid).setAccessLevel(newlevel);
           return "Access level change sucessfull.";
       }
       return "You do not have the authority to do that.";
    }
    public main.java.memoranda.User finduser(int id){
       return list.get(id);
    }
    public int accesslevel(){
       return currentuser.getaccesslevel();
    }
    public int getcurrentuser(){
       return currentuser.getuserID();
    }
    public void logout(){
       currentuser=guest;
    }
    public void changeBelt(int newBelt, int userID){

    }

    // debugging
    public int size() {
       return list.size();
    }
}

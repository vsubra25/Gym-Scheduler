package main.java.memoranda.util;

public class CreateClassInfo {
    private static LoadableProperties messages = new LoadableProperties();
    private static boolean disabled = false;
    private static String[] rooms = {"Kiritsu", "Chikara", "Chie", "Doryoku"};
    private static String[] classType = {"Public", "Private"};

    public static String[] getRoomNames() {
        String[] localRoomNames = new String[4];
        String[] roomNames = rooms;

        roomNames =
                new String[]{
                        "Chie",
                        "Chikara",
                        "Doryoku",
                        "Kiritsu"
                };

        for (int i = 0; i < 4; i++) {
            localRoomNames[i] = getString(roomNames[i]);
        }
        return localRoomNames;
    }

    public static String[] getClassType() {
        String[] localClassType = new String[2];
        String[] classTypes = classType;

        classTypes =
                new String[]{
                        "Public",
                        "Private",
                };

        for (int i = 0; i < 2; i++) {
            localClassType[i] = getString(classTypes[i]);
        }
        return localClassType;
    }

    public static String getString(String key) {
        if ((messages == null) || (disabled)) {
            return key;
        }
        String msg = (String) messages.get(key.trim().toUpperCase());
        if ((msg != null) && (msg.length() > 0)) {
            return msg;
        }
        else {
            return key;
        }
    }
}
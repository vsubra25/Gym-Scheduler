package main.java.memoranda;

public class User {
    int id;
    String Username;
    String Password;
    int usertype;
    int accesslevel;
    String fname;
    String lname;
    String email;
    String phone;
    int belt;
    /* base user class
    * Access level: 0=guest, 1=member,2=trainer,3=owner
    *  */
    public User(String UserN,String PassW,String fn,String ln,String phn, String eml, int belt, int access, int idn){
        Username=UserN;
        Password=PassW;
        fname=fn;
        lname=ln;
        phone = phn;
        email = eml;
        usertype = belt;
        accesslevel = access;
        id=idn;
    }
    public boolean login(String usn,String psn){
        if(usn==Username && psn==Password){
            return true;
        }
        else {
            return false;
        }
    }
    public String getname(){
        String name=fname + " " + lname;
        return name;
    }
    public String getphone(){
        return phone;
    }
    public String getemail(){
        return email;
    }
    public int getaccesslevel(){
        return accesslevel;
    }
    public int getUsertype(){
        return usertype;
    }
    public int getuserID(){
        return id;
    }
    public void setAccessLevel(int i){
        accesslevel=i;
    }
    public void setuserType(int u){
        usertype=u;
    }
    public void changeBelt(int newBelt){
        belt=newBelt;
    }
}

/**
 * DefaultScheduleNotifier.java Created on 10.03.2003, 21:18:02 Alex Package:
 * net.sf.memoranda
 * 
 * @author Alex V. Alishevskikh, alex@openmechanics.net Copyright (c) 2003
 *         Memoranda Team. http://memoranda.sf.net
 */
package main.java.memoranda;

import main.java.memoranda.ui.EventNotificationDialog;

/**
 *  
 */
/*$Id: DefaultScheduleNotifier.java,v 1.4 2004/01/30 12:17:41 alexeya Exp $*/
public class DefaultScheduleNotifier implements ScheduleNotificationListener {

	/**
	 * Constructor for DefaultScheduleNotifier.
	 */
	public DefaultScheduleNotifier() {
		super();
	}

	/**
	 * @see ScheduleNotificationListener#eventIsOccured(ClassSchedule)
	 */
	public void eventIsOccured(ClassSchedule ev) {
		new EventNotificationDialog(
			"Memoranda event",
			ev.getTimeString(),
			ev.getText());
	}
	/**
	 * @see ScheduleNotificationListener#eventsChanged()
	 */
	public void eventsChanged() {
		//
	}

	
}

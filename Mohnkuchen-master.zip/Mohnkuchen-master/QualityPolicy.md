### Quality Policy
> Describe your Quality Policy in detail for this Sprint (remember what I ask you to do when I talk about the "In your Project" part in the lectures and what is mentioned after each assignment (in due course you will need to fill out all of them, check which ones are needed for each Deliverable). You should keep adding things to this file and adjusting your policy as you go.

**GitHub Workflow** (due Feb 2nd)
  
   1. Master branch should always be a working and stable copy of Dojo
   2. Team members are to work from a Development branch that may be merged into master once it is tested and reviewed
   3. One branch must be created for each User Story, named US# where # is the number of the User Story from Product Backlog
   4. Sub branches may be created for different tasks in the format "US#-Task#-Description" or "US#-Description" depending on the size of US
   5. Commit messages must describe what the team member worked on with the US#, Task #, and brief description
   6. Nothing should be merged into master without a Pull Request
   7. Pull Requests to Development and Master branches should always be fast-forwards
   8. At least one team member should approvate a Pull Request after reviewing and testing
   9. Only the Git Master shall merge into master
   10. If Git master is unavailable to merge into master, another team member may do so with a comment as to why

**Unit Tests Blackbox** (due start Sprint 2)
  > Blackbox implemetation will show correct inputs and outputs for the tested classes and methods.

 **Unit Tests Whitebox** (due Feb 25th)
  > Create Whitebox unit tests that will test expected values against actual values of methods created by the team. Comments will be added to each test class to provide an explanation of what is being tested along with the expected value and whether the test will pass or fail.

**Code Review** (due Feb 25th)
  > Your Code Review policy   

  > Include a checklist/questions list which every developer will need to fill out/answe when creating a Pull Request to the Dev branch. 
   1. List the java files that are significant to the US related to the Pull Request
   2. Provide a description of what has been added/modified
   3. Make sure the description is related to the tasks on hand

  > Include a checklist/question list which every reviewer will need to fill out/anser when conducting a review, this checklist (and the answers of course) need to be put into the Pull Request review.
   1. Read the description that was included with the Pull Request
   2. Test all criteria in the the comments of the Pull Request
   3. Spend a decent amount of time testing other features that were added/modified in previous User Stories to find possible bugs that can be fixed in the future

**Static Analysis**  (due start Sprint 3)
  > Your Static Analysis policy   

**Continuous Integration**  (due start Sprint 3)
  > Your Continuous Integration policy

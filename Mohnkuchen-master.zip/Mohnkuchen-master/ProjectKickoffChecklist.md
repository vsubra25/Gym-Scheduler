For each of you individually copy the checklist and check them of if it is done. This will be graded.

Luis Ramirez
  
- [X] Download and install Git
  
- [X] I have a GitHub account with a username that we can map to your real name

- [X] Filled out the individual survey for group forming

- [X] Received a Taiga invite

- [X] Accepted the Taiga invite

- [X] Do you check Slack regularly

- [X] Did you contact your team members

- [X] Did you read the kickoff document

- [X] Did you understand the kickoff document

- [X] Did you make your three changes to the Memoranda software

- [X] Did you read the DeliverableX.md document and understand it (if you do not understand ask your team or me)

- [X] Did you read the QualityPolicy.md doument and understand it (if you do not understand ask your team or me)

- [X] You understand how to get started and what the next steps in my project are based on the kickoff document and what you learned about Scrum and GitHub (if you do not, ask on Slack until you do and can check this)
